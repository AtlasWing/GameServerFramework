?package(tolua++):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="tolua++" command="/usr/bin/tolua++"
