// TestGameClient.h : main header file for the TESTGAMECLIENT application
//

#if !defined(AFX_TESTGAMECLIENT_H__3B87039A_A862_4292_9619_EC357C6056BB__INCLUDED_)
#define AFX_TESTGAMECLIENT_H__3B87039A_A862_4292_9619_EC357C6056BB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientApp:
// See TestGameClient.cpp for the implementation of this class
//

class CTestGameClientApp : public CWinApp
{
public:
	CTestGameClientApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestGameClientApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestGameClientApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTGAMECLIENT_H__3B87039A_A862_4292_9619_EC357C6056BB__INCLUDED_)
