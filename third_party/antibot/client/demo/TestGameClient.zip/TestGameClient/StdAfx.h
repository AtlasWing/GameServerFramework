// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__90B6B5DF_7528_475F_9D7E_2768EC87FE6D__INCLUDED_)
#define AFX_STDAFX_H__90B6B5DF_7528_475F_9D7E_2768EC87FE6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxsock.h>

#define USE_DYNA_LIB
#define USE_DPROTO
#include "../../sdk/AntiBotImport.h"

#include <stdio.h>
inline void DebugOutHex(BYTE *pbyHex, DWORD dwLen);
inline void DebugOut(const char *pszFormat, ...);

#ifdef _DEBUG
#define DEBUG_OUT DebugOut
#define DEBUG_OUT_HEX DebugOutHex
#else
#define DEBUG_OUT
#define DEBUG_OUT_HEX
#endif

inline void DebugOut(const char *pszFormat, ...)
{
    char *pszMsg = new char[40960];
	memset(pszMsg, 0, 40960);
    
    va_list ap;
    va_start(ap, pszFormat);
    vsprintf(pszMsg, pszFormat, ap);
    va_end(ap);
	
    ::OutputDebugString(pszMsg);
	
	delete[] pszMsg;
}

inline void DebugOutHex(BYTE *pbyHex, DWORD dwLen)
{
	char *pszHex = new char[2 * dwLen + 1];
	memset(pszHex, 0, 2 * dwLen + 1);
	
	char szTmp[3] = {0};
	for (DWORD i = 0; i < dwLen; i++)
	{
		sprintf(szTmp, "%02X", pbyHex[i]);
		strcat(pszHex, szTmp);
	}
	DebugOut("%s\n", pszHex);
	
	delete[] pszHex;
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__90B6B5DF_7528_475F_9D7E_2768EC87FE6D__INCLUDED_)
