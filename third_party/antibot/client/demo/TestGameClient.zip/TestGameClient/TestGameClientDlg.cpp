// TestGameClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestGameClient.h"
#include "TestGameClientDlg.h"
#include "MersenneTwister.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define CFG_NAME      "client.ini"

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientDlg dialog
CTestGameClientDlg* CTestGameClientDlg::m_psInstance = NULL;

CTestGameClientDlg* CTestGameClientDlg::GetInstance()
{
	if (NULL == m_psInstance)
	{
		m_psInstance = new CTestGameClientDlg();
	}
	
	return m_psInstance;
}

CTestGameClientDlg::CTestGameClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestGameClientDlg::IDD, pParent), m_pAntiBot(NULL), m_pDProto(NULL)
{
	//{{AFX_DATA_INIT(CTestGameClientDlg)
	m_strSvrIp = _T("10.2.141.46");
	m_wPort = 6666;
	m_dwUin = 0;
	m_nChangeSvrTimer = 0;
	m_dwChangeSvrTimerGap = 5 * 60 * 1000;
	m_pszCfgFilePath = NULL;

	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_pSocket = NULL;
}

void CTestGameClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestGameClientDlg)
	DDX_Text(pDX, IDC_EDIT_IP, m_strSvrIp);
	DDV_MaxChars(pDX, m_strSvrIp, 15);
	DDX_Text(pDX, IDC_EDIT_PORT, m_wPort);
	DDV_MinMaxDWord(pDX, m_wPort, 0, 65535);
	DDX_Text(pDX, IDC_EDIT_UIN, m_dwUin);
	DDV_MinMaxDWord(pDX, m_dwUin, 1000, 999999);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestGameClientDlg, CDialog)
	//{{AFX_MSG_MAP(CTestGameClientDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_CLOSE, OnBtnClose)
	ON_BN_CLICKED(IDC_BTN_CONNECT, OnBtnConnect)
	ON_BN_CLICKED(IDC_BTN_START, OnBtnStart)
	ON_BN_CLICKED(IDC_BTN_END, OnBtnEnd)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientDlg message handler
//#define CHANGE_SERVER_TIMER_GAP  15 * 60 *1000

BOOL CTestGameClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
		
	m_pAntiBot = (AntiBot::IAntiBot*)AntiBot::CreateAntiObj(AntiBot::ANTI_OBJ_ANTIBOT);
	ASSERT(m_pAntiBot);

	if (m_nChangeSvrTimer)
	{
		::KillTimer(NULL, m_nChangeSvrTimer);
		m_nChangeSvrTimer = 0;
	}

	char szCfgFilePath[_MAX_PATH] = {0};
	::GetModuleFileName(NULL, szCfgFilePath, MAX_PATH);
	*(strrchr(szCfgFilePath, '\\') + 1) = 0;
	
	DWORD dwRemaining = (sizeof(szCfgFilePath) - strlen(szCfgFilePath)) - 1;
	strncat(szCfgFilePath, CFG_NAME, dwRemaining);	

	m_pszCfgFilePath = strdup(szCfgFilePath);

	m_dwChangeSvrTimerGap = (DWORD)GetPrivateProfileInt("timer", "changeserver", 30 * 60 * 1000, m_pszCfgFilePath);
	m_nChangeSvrTimer = ::SetTimer(NULL, 0, m_dwChangeSvrTimerGap, ChangeSvrTimerProc);
	ASSERT(m_nChangeSvrTimer);

	//m_pDProto = (AntiBot::IDProto*)AntiBot::CreateAntiObj(AntiBot::ANTI_OBJ_DPROTO);
	//ASSERT(m_pDProto);
	//m_pDProto->Init();
	//m_pDProto->Init(0, NULL);
	OnBtnConnect();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestGameClientDlg::ChangeSvrTimerProc(HWND hWnd, UINT uMsg, unsigned int idEvent, DWORD dwTime)
{
	CTestGameClientDlg *pobjDlg = CTestGameClientDlg::GetInstance();
	pobjDlg->OnBtnClose();
	pobjDlg->OnBtnConnect();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestGameClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CTestGameClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestGameClientDlg::OnBtnClose() 
{
	if (m_pSocket)
	{
		m_pSocket->Close();
		delete m_pSocket;
		m_pSocket = NULL;
	}
}

#define DEST_IP "172.25.40.47"
#define DESR_PORT 443
// #define DEST_IP "10.2.141.133"
// #define DESR_PORT 6666

void CTestGameClientDlg::OnBtnConnect() 
{
#ifndef USE_CFG

	srand(GetTickCount());
	MTRand ObjMtRand;

	//10000�û�ID��Server��������;�����˵�
	while (TRUE)
	{
		if (m_dwUin == 10000)
		{
			//m_dwUin = (DWORD)rand();
			//m_dwUin <<= 16;
			m_dwUin = ObjMtRand.randInt(1147483647);
			m_dwUin |= (DWORD)rand();

			if (m_dwUin == 10000)
			{
				continue;
			}
			
			break;
		}
			
		break;
	}
#else

	while (TRUE)
	{
		if (m_dwUin != 0)
		{
			break;
		}
		
		DWORD dwMinUin = (DWORD)GetPrivateProfileInt("range", "min", 0, m_pszCfgFilePath);
		DWORD dwMaxUin = (DWORD)GetPrivateProfileInt("range", "max", 0, m_pszCfgFilePath);
		m_dwUin = (DWORD)GetPrivateProfileInt("range", "uin", 0, m_pszCfgFilePath);
		
		if (m_dwUin == 0)
		{
			m_dwUin = dwMinUin;
		}
		
		ASSERT(m_dwUin <= dwMaxUin);
		ASSERT(m_dwUin >= dwMinUin);
		
		char szBuffer[20] = {0};
		
		WritePrivateProfileString("range", "uin", ultoa(m_dwUin + 1, szBuffer, 10), m_pszCfgFilePath);
		break;
	}
	
	char szIP[20] = {0};
	GetPrivateProfileString("server", "ip", "172.25.40.47", szIP, sizeof(szIP), m_pszCfgFilePath);
	m_strSvrIp = szIP;
	m_wPort = (WORD)GetPrivateProfileInt("server", "port", 0, m_pszCfgFilePath);
		
#endif

	//m_dwUin = (DWORD)rand();
// 	m_strSvrIp = CString(DEST_IP);
// 	m_wPort = DESR_PORT;
// 	printf("\nuser id: %d-----server ip: %s-----server port: %d---", m_dwUin, (const char*)m_strSvrIp, m_wPort);
 	//UpdateData();
	if (m_pSocket == NULL)
	{
		m_pSocket = new CTestGameClientSocket();
	}

	if(!m_pDProto)
	{
		m_pDProto = (AntiBot::IDProto*)AntiBot::CreateAntiObj(AntiBot::ANTI_OBJ_DPROTO);
		ASSERT(m_pDProto);
	}
//	else
//	{
		//m_pDProto->NotifyChangeSvr();
//	}
#ifdef USE_NEWDP
	m_pDProto->Init(10000000, (AntiBot::IDPClientSink*)m_pSocket);
#else
	m_pDProto->Init();
#endif
	

	m_pAntiBot->SetUserInfo(10000000, m_dwUin, (AntiBot::IClientSink*)m_pSocket);
	
	m_pSocket->LoginServer(m_dwUin, m_strSvrIp, (WORD)m_wPort, m_pDProto);
	UpdateData(FALSE);
}

void CTestGameClientDlg::OnBtnStart() 
{
	BYTE *pbyGameStartData = NULL;
	DWORD dwGameStartSize = 0;

	m_pSocket->EncodeGameProto_GameStatus(1, &pbyGameStartData, dwGameStartSize);
	m_pSocket->SendData(pbyGameStartData, (WORD)dwGameStartSize);
	delete[] pbyGameStartData;

	m_pAntiBot->StartLocalOnceCheck();
	
	DEBUG_OUT("not implement game start.");
}

void CTestGameClientDlg::OnBtnEnd() 
{
	BYTE *pbyGameEndData = NULL;
	DWORD dwGameEndSize = 0;

	m_pSocket->EncodeGameProto_GameStatus(2, &pbyGameEndData, dwGameEndSize);
	m_pSocket->SendData(pbyGameEndData, (WORD)dwGameEndSize);
	delete[] pbyGameEndData;

	DEBUG_OUT("not implement game end.");
}

void CTestGameClientDlg::OnClose() 
{
	OnBtnClose();
	
	if (m_pAntiBot)
	{
		m_pAntiBot->Release();
		m_pAntiBot = NULL;
	}

	if (m_pDProto)
	{
		m_pDProto->Release();
		m_pDProto = NULL;
	}
	
	CDialog::OnClose();
}
