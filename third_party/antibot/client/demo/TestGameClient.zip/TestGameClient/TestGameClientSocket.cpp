// TestGameClientSocket.cpp : implementation file
//

#include "stdafx.h"
#include "TestGameClient.h"
#include "TestGameClientSocket.h"

#include "CRC32.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientSocket

CTestGameClientSocket::CTestGameClientSocket()
{
	m_dwRemainSizeRcv = 0;
	m_pbyCacheBufRcv = new BYTE[MAX_CACHE_BUF_SIZE];
	memset(m_pbyCacheBufRcv, 0, MAX_CACHE_BUF_SIZE);

	m_dwRemainSizeSnd = 0;
	m_pbyCacheBufSnd = new BYTE[MAX_CACHE_BUF_SIZE];
	memset(m_pbyCacheBufSnd, 0, MAX_CACHE_BUF_SIZE);
	
	m_pAntiBot = NULL;
	m_dwPkgCounter = 0;

	m_dwUin = 0;
}

CTestGameClientSocket::~CTestGameClientSocket()
{
	m_dwRemainSizeRcv = 0;
	if (m_pbyCacheBufRcv)
	{
		delete[] m_pbyCacheBufRcv;
		m_pbyCacheBufRcv = NULL;
	}

	m_dwRemainSizeSnd = 0;
	if (m_pbyCacheBufSnd)
	{
		delete[] m_pbyCacheBufSnd;
		m_pbyCacheBufSnd = NULL;
	}
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CTestGameClientSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CTestGameClientSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientSocket member functions

void CTestGameClientSocket::EncodeGameProto_Close(BYTE **ppbyGameProtoInitData, DWORD& dwGameProtoInitSize)
{
	dwGameProtoInitSize = sizeof(GAMEPROTO_HEAD);
	*ppbyGameProtoInitData = new BYTE[dwGameProtoInitSize];

	GAMEPROTO_HEAD *pstGameProtoHead = (GAMEPROTO_HEAD*)(*ppbyGameProtoInitData);
	pstGameProtoHead->dwSize = htonl(0);
	pstGameProtoHead->wProtoId = (WORD)GAMEPROTO_CLOSE;
	pstGameProtoHead->dwCrc = 0;
}

void CTestGameClientSocket::EncodeGameProto_Init(DWORD dwUin, DWORD dwCliVer, BYTE **ppbyGameProtoInitData, DWORD& dwGameProtoInitSize)
{
	dwGameProtoInitSize = sizeof(GAMEPROTO_HEAD) + 2 * sizeof(DWORD);
	*ppbyGameProtoInitData = new BYTE[dwGameProtoInitSize];

	DWORD dwProcLen = sizeof(GAMEPROTO_HEAD);

	DWORD dwTmp = htonl(dwUin);
	memmove(*ppbyGameProtoInitData + dwProcLen, &dwTmp, sizeof(DWORD));
	dwProcLen += sizeof(DWORD);

	dwTmp = htonl(dwCliVer);
	memmove(*ppbyGameProtoInitData + dwProcLen, &dwTmp, sizeof(DWORD));
	dwProcLen += sizeof(DWORD);

	GAMEPROTO_HEAD *pstGameProtoHead = (GAMEPROTO_HEAD*)(*ppbyGameProtoInitData);
	pstGameProtoHead->dwSize = htonl(dwProcLen - sizeof(GAMEPROTO_HEAD));
	pstGameProtoHead->wProtoId = (WORD)GAMEPROTO_INIT;
	pstGameProtoHead->dwCrc = CCrc32::Crc32(*ppbyGameProtoInitData + sizeof(GAMEPROTO_HEAD), dwGameProtoInitSize - sizeof(GAMEPROTO_HEAD));
}

void CTestGameClientSocket::EncodeGameProto_AntiBot(BYTE *pbyAntiBotData, DWORD dwAntiBotSize, BYTE **ppbyGameProtoAntiBotData, DWORD& dwGameProtoAntiBotSize)
{
	dwGameProtoAntiBotSize = dwAntiBotSize + sizeof(GAMEPROTO_HEAD);
	*ppbyGameProtoAntiBotData = new BYTE[dwGameProtoAntiBotSize];

	memmove(*ppbyGameProtoAntiBotData + sizeof(GAMEPROTO_HEAD), pbyAntiBotData, dwAntiBotSize);

	GAMEPROTO_HEAD *pstGameProtoHead = (GAMEPROTO_HEAD*)(*ppbyGameProtoAntiBotData);
	pstGameProtoHead->dwSize = htonl(dwAntiBotSize);
	pstGameProtoHead->wProtoId = (WORD)GAMEPROTO_ANTIBOT;
	pstGameProtoHead->dwCrc = CCrc32::Crc32(*ppbyGameProtoAntiBotData + sizeof(GAMEPROTO_HEAD), dwGameProtoAntiBotSize - sizeof(GAMEPROTO_HEAD));
}

void CTestGameClientSocket::DecodeGameProto(BYTE *pbyGameProtoData, DWORD dwGameProtoSize, BYTE **ppbyData, DWORD& dwSize)
{
	dwSize = dwGameProtoSize - sizeof(GAMEPROTO_HEAD);
	*ppbyData = new BYTE[dwSize];

	GAMEPROTO_HEAD *pstGameProtoHead = (GAMEPROTO_HEAD*)pbyGameProtoData;
	//DEBUG_OUT("GameClient:OnRcvData:Decode:%u", ntohl(pstGameProtoHead->dwSize));
	//ASSERT(ntohl(pstGameProtoHead->dwSize) == dwSize);

	DWORD dwCrc = CCrc32::Crc32(pbyGameProtoData + sizeof(GAMEPROTO_HEAD), dwGameProtoSize - sizeof(GAMEPROTO_HEAD));
	ASSERT(dwCrc == pstGameProtoHead->dwCrc);

	memmove(*ppbyData, pbyGameProtoData + sizeof(GAMEPROTO_HEAD), dwSize);
}

void CTestGameClientSocket::EncodeGameProto_GameStatus(BYTE byGameStatus, BYTE **ppbyGameStartData, DWORD& dwGameStartSize)
{
	dwGameStartSize = sizeof(GAMEPROTO_HEAD) + sizeof(BYTE);
	*ppbyGameStartData = new BYTE[dwGameStartSize];

	*(BYTE*)(*ppbyGameStartData + sizeof(GAMEPROTO_HEAD)) = byGameStatus;

	GAMEPROTO_HEAD *pstGameProtoHead = (GAMEPROTO_HEAD*)(*ppbyGameStartData);
	pstGameProtoHead->dwCrc = CCrc32::Crc32(*ppbyGameStartData + sizeof(GAMEPROTO_HEAD), dwGameStartSize - sizeof(GAMEPROTO_HEAD));
	pstGameProtoHead->dwSize = htonl(1);
	pstGameProtoHead->wProtoId = GAMEPROTO_GAMESTATUS;
}

void CTestGameClientSocket::EncodeGameProto(BYTE *pbyGameProtoData, DWORD dwGameProtoSize, WORD wProtoId, BYTE **ppbyData, DWORD& dwSize)
{
	dwSize = sizeof(GAMEPROTO_HEAD) + dwGameProtoSize;
	*ppbyData = new BYTE[dwSize];
	
	memmove(*ppbyData + sizeof(GAMEPROTO_HEAD), pbyGameProtoData, dwGameProtoSize);
	
	GAMEPROTO_HEAD *pstGameProtoHead = (GAMEPROTO_HEAD*)(*ppbyData);
	pstGameProtoHead->dwCrc = CCrc32::Crc32(*ppbyData + sizeof(GAMEPROTO_HEAD), dwSize - sizeof(GAMEPROTO_HEAD));
	pstGameProtoHead->dwSize = htonl(dwGameProtoSize);
	pstGameProtoHead->wProtoId = wProtoId;
}

void CTestGameClientSocket::EncodeGameProto_RequestData(BYTE *pbyAntiBotData, DWORD dwAntiBotSize, BYTE **ppbyGameProtoAntiBotData, DWORD& dwGameProtoAntiBotSize)
{
	dwGameProtoAntiBotSize = dwAntiBotSize + sizeof(GAMEPROTO_HEAD);
	*ppbyGameProtoAntiBotData = new BYTE[dwGameProtoAntiBotSize];

	memmove(*ppbyGameProtoAntiBotData + sizeof(GAMEPROTO_HEAD), pbyAntiBotData, dwAntiBotSize);

	GAMEPROTO_HEAD *pstGameProtoHead = (GAMEPROTO_HEAD*)(*ppbyGameProtoAntiBotData);
	pstGameProtoHead->dwSize = htonl(dwAntiBotSize);
	pstGameProtoHead->wProtoId = (WORD)GAMEPROTO_REQUESTDATAFORDP;
	pstGameProtoHead->dwCrc = CCrc32::Crc32(*ppbyGameProtoAntiBotData + sizeof(GAMEPROTO_HEAD), dwGameProtoAntiBotSize - sizeof(GAMEPROTO_HEAD));
}


int CTestGameClientSocket::SendDataToSvr(BYTE *pbyData, DWORD dwSize)
{
	BYTE *pbyGameProtoData = NULL;
	DWORD dwGameProtoSize = 0;
	WORD wProtoID = *(WORD*)pbyData;

	if (ntohs(wProtoID) == 4)
	{
		m_dwPkgCounter ++;
		*(DWORD*)(pbyData + sizeof(WORD) * 2) = htonl(m_dwPkgCounter);
	}

	EncodeGameProto_AntiBot(pbyData, dwSize, &pbyGameProtoData, dwGameProtoSize);
	//EncodeGameProto_RequestData(pbyData, dwSize, &pbyGameProtoData, dwGameProtoSize);
	SendData(pbyGameProtoData, (WORD)dwGameProtoSize);
	delete[] pbyGameProtoData;

	return true;
}

#ifdef USE_NEWDP
//���Ͷ�̬Э��ջ����
int CTestGameClientSocket::SendDataToServer(BYTE *pbyData, DWORD dwSize)
{
	BYTE *pbyGameProtoData = NULL;
	DWORD dwGameProtoSize = 0;
	EncodeGameProto(pbyData, dwSize, GAMEPROTO_DPROTO, &pbyGameProtoData, dwGameProtoSize);
	SendData(pbyGameProtoData, (WORD)dwGameProtoSize);
	delete[] pbyGameProtoData;

	return true;
}

#endif

void CTestGameClientSocket::LoginServer(DWORD dwUin, const char *pszSvrIp, WORD wPort, AntiBot::IDProto *pDProto)
{
	ASSERT(wPort < 65535 && pszSvrIp && pDProto);
	m_dwUin = dwUin;
	m_pDProto = pDProto;

	BOOL bRetCode = FALSE;

	if (!m_pAntiBot)
	{
		m_pAntiBot = (AntiBot::IAntiBot*)AntiBot::CreateAntiObj(AntiBot::ANTI_OBJ_ANTIBOT);
	}
	ASSERT(m_pAntiBot);
 
	if (m_hSocket)
	{
		Close();
	}

	bRetCode = Create();
	ASSERT(bRetCode);
   
	bRetCode = Connect(pszSvrIp, wPort);
	//ASSERT(bRetCode);
	ASSERT(bRetCode == 0 && WSAEWOULDBLOCK == GetLastError() || !bRetCode);
}

void CTestGameClientSocket::OnRcvData(BYTE *pbyPkgData, WORD wPkgSize)
{
	DEBUG_OUT("GameClient:OnRcvData:%u", wPkgSize);

	GAMEPROTO_HEAD *pstGameProtoData = (GAMEPROTO_HEAD*)pbyPkgData;

	BYTE *pbyData = NULL;
	DWORD dwSize = 0;
	DecodeGameProto(pbyPkgData, wPkgSize, &pbyData, dwSize);
	DEBUG_OUT_HEX(pbyData, dwSize > 100 ? 100 : dwSize);

	m_pDProto->CheckProtoStatus(pstGameProtoData->wProtoId);

	if (pstGameProtoData->wProtoId == GAMEPROTO_DPROTO)
	{
		int nRetCode = false;
		

		nRetCode = m_pDProto->OnGetData(pbyData);
		switch (nRetCode)
		{
		case AntiBot::IDProto::AnalyseOK:
			DEBUG_OUT("GameClient:OnRcvData:OnGetData:AnalyseOK:%u", dwSize);
			break;
		case AntiBot::IDProto::AnalyseFail:
			DEBUG_OUT("GameClient:OnRcvData:OnGetData:AnalyseFail:%u:%u", dwSize, m_pDProto->GetLastError());
			ASSERT(false);
			break;
		case AntiBot::IDProto::GetCryptedData:
			{
				BYTE *pbyRawData = NULL;
				DWORD dwRawSize = 0;
				m_pDProto->GetVMDataBuf(pbyRawData, dwRawSize);
				
				delete[] pbyData;
				pbyData = NULL;

				DEBUG_OUT("GameClient:OnRcvData:OnGetData:GetCryptedData:%u", dwRawSize);
				DEBUG_OUT_HEX(pbyRawData, dwRawSize > 100 ? 100 : dwRawSize);
				
				pstGameProtoData = (GAMEPROTO_HEAD*)pbyRawData;
				DecodeGameProto(pbyRawData, dwRawSize, &pbyData, dwSize);
				DEBUG_OUT_HEX(pbyData, dwSize > 100 ? 100 : dwSize);
			}
			break;
			/*
			//�������ʧ�ܣ��ϱ�client��ǰ״̬������server�ط����������ݰ�
		case AntiBot::IDProto::PieceCrcError:
			{
				WORD wPkgLen = 1024;
				BYTE byPkgData[1024] = {0};

				if(m_pDProto->GetResendPackage(byPkgData + 2, &wPkgLen))
				{
					BYTE *pbyGameProtoData = NULL;
					DWORD dwGameProtoSize = 0;
					*((WORD*)byPkgData) = htons(SC_AB_VM_PROTO);
					EncodeGameProto_RequestData(byPkgData, wPkgLen + 2, &pbyGameProtoData, dwGameProtoSize);
					SendData(pbyGameProtoData, dwGameProtoSize);
					delete[] pbyGameProtoData;
					pbyGameProtoData = NULL;
				}
				else
				{
					DEBUG_OUT("GetResendPackage Error, size = %u", wPkgLen);
					ASSERT(false);
				}

			}
			*/
		default:
			ASSERT(false);
			break;
		}
	}

	switch (pstGameProtoData->wProtoId) 
	{
	case GAMEPROTO_ANTIBOT:
		{
			m_pAntiBot->OnRcvAntiData(pbyData, dwSize);
		}
		break;
	case GAMEPROTO_DPROTO:
		break;
	case GAMEPROTO_TEST_DP:
		DEBUG_OUT("%u:%s", dwSize, (char*)pbyData);
		break;
	default:
		ASSERT(false);
		break;
	}

	delete[] pbyData;
}

void CTestGameClientSocket::SendData(BYTE *pbyData, WORD wSize)
{
	int nRetCode = false;
	DWORD dwLastError = 0;

	BYTE *pbySndData = pbyData;
	DWORD dwSndSize = wSize;
	bool bDPData = false;

	GAMEPROTO_HEAD *pstGameProtoData = (GAMEPROTO_HEAD*)pbyData;

	if (m_pDProto->NeedEncrypt(pstGameProtoData->wProtoId))
	{
		nRetCode = m_pDProto->Encrypt(pbyData, wSize);
		if (nRetCode)
		{
			BYTE *pbyDPData = NULL;
			DWORD dwDPSize = 0;
			m_pDProto->GetUPVMDataBuf(pbyDPData, dwDPSize);
			DEBUG_OUT("GameClient:SendData:Encrypt:%u", dwDPSize);


			EncodeGameProto(pbyDPData, dwDPSize, GAMEPROTO_DPROTO, &pbySndData, dwSndSize);
			bDPData = true;
		}
		else
		{
			DEBUG_OUT("CTestGameClientSocket:SendData:%u", m_pDProto->GetLastError());
			
			ASSERT(false);
		}
	}

#ifdef TESTLINUXSVR
	BYTE* pbySendBuffer = new BYTE[dwSndSize + 4];
	//BYTE szSendBuffer[50000];
	unsigned short usTemp = htons(dwSndSize + 4);
	memcpy(pbySendBuffer, &usTemp, 2);
	usTemp = htons(dwSndSize);
	memcpy(pbySendBuffer + 2, &usTemp, 2);
	memcpy(pbySendBuffer + 4, pbySndData, dwSndSize);
	SendData2(pbySendBuffer, dwSndSize+4);
	delete []pbySendBuffer;
#else
	SendData2(pbySndData, dwSndSize);
#endif
	

	if (bDPData)
	{
		delete[] pbySndData;
		pbySndData = NULL;
	}
}


void CTestGameClientSocket::SendData2(BYTE *pbySndData, WORD dwSndSize)
{
	int nRetCode = false;
	DWORD dwLastError = 0;

	nRetCode = CAsyncSocket::Send(pbySndData, dwSndSize);
	DEBUG_OUT("GameClient:SendData2:%u", dwSndSize);
	DEBUG_OUT_HEX(pbySndData, dwSndSize);
	dwLastError = ::GetLastError();

	if (nRetCode == SOCKET_ERROR)
	{
		if (dwLastError == WSAEWOULDBLOCK)
		{
			memmove(m_pbyCacheBufSnd + m_dwRemainSizeSnd, pbySndData, dwSndSize);
			m_dwRemainSizeSnd += dwSndSize;
			DEBUG_OUT("GameClient:SendData SOCKET_ERROR Cached:%x", dwLastError);
		}
		else
		{
			DEBUG_OUT("GameClient:SendData SOCKET_ERROR:%x", dwLastError);
			ASSERT(false);
		}
	}
	else if (nRetCode < dwSndSize)
	{
		memmove(m_pbyCacheBufSnd + m_dwRemainSizeSnd, pbySndData + nRetCode, dwSndSize - nRetCode);
		m_dwRemainSizeSnd += (dwSndSize - nRetCode);
		DEBUG_OUT("GameClient:SendData PART:%u:%u", nRetCode, dwSndSize);
	}
	else if (nRetCode == dwSndSize)
	{
		DEBUG_OUT("GameClient:SendData SUCCESS:%u", dwSndSize);
	}
	else
	{
		DEBUG_OUT("GameClient:SendData ERROR");
		ASSERT(false);
	}
}

//
void CTestGameClientSocket::OnConnect(int nErrorCode) 
{
	DEBUG_OUT("GameClient:OnConnect:%u", nErrorCode);
	ASSERT(nErrorCode == 0);
	
	DWORD dwCliVer = GetExeVer();

	BYTE *pbyGameProtoData = NULL;
	DWORD dwGameProtoSize = 0;
	EncodeGameProto_Init(m_dwUin, dwCliVer, &pbyGameProtoData, dwGameProtoSize);
	SendData(pbyGameProtoData, (WORD)dwGameProtoSize);
	delete[] pbyGameProtoData;

#ifdef USE_NEWDP
	m_pDProto->SendInitData();
#endif

	m_pAntiBot->SendInitData();
	
	CAsyncSocket::OnConnect(nErrorCode);
}

void CTestGameClientSocket::SendClose()
{
	BYTE *pbyGameProtoData = NULL;
	DWORD dwGameProtoSize = 0;
	EncodeGameProto_Close(&pbyGameProtoData, dwGameProtoSize);
	SendData(pbyGameProtoData, (WORD)dwGameProtoSize);
	delete[] pbyGameProtoData;
}

void CTestGameClientSocket::OnSend(int nErrorCode) 
{
	int nRetCode = false;
	DWORD dwLastError = 0;

	while (m_dwRemainSizeSnd > 0)
	{
		nRetCode = Send(m_pbyCacheBufSnd, m_dwRemainSizeSnd);
		dwLastError = ::GetLastError();
		if (nRetCode == SOCKET_ERROR)
		{
			if (dwLastError == WSAEWOULDBLOCK)
			{
				DEBUG_OUT("GameClient:OnSend SOCKET_ERROR WSAEWOULDBLOCK");
				break;
			}
			else
			{
				DEBUG_OUT("GameClient:OnSend ERROR");
				ASSERT(false);
			}
		}
		else
		{
			memmove(m_pbyCacheBufSnd, m_pbyCacheBufSnd + nRetCode, m_dwRemainSizeSnd - nRetCode);
			m_dwRemainSizeSnd -= nRetCode;
			DEBUG_OUT("GameClient:OnSend:%u:%u", nRetCode, m_dwRemainSizeSnd);
		}
	}

	CAsyncSocket::OnSend(nErrorCode);
}

void CTestGameClientSocket::OnReceive(int nErrorCode) 
{
	while (true)
	{
		int nRcvSize = Receive(m_pbyCacheBufRcv + m_dwRemainSizeRcv, MAX_CACHE_BUF_SIZE - m_dwRemainSizeRcv);
		if (nRcvSize <= 0)
			break;

		int nTotalSize = nRcvSize + m_dwRemainSizeRcv;

		int nProcSize = 0;
		bool bNotGetFullPkg = false;
		int iGap = 0;
#ifdef TESTLINUXSVR
		iGap = 4;
#endif
		do 
		{
			BYTE *pbyBuf = m_pbyCacheBufRcv + nProcSize;
			DWORD dwPkgSize = ntohl(*(DWORD*)(pbyBuf + iGap)) + sizeof(GAMEPROTO_HEAD);
			ASSERT(dwPkgSize < MAX_PKG_SIZE);
			if (nProcSize + iGap + dwPkgSize >= nTotalSize)
			{
				bNotGetFullPkg = true;
			}

			if (nProcSize + iGap + dwPkgSize <= nTotalSize)
			{
				BYTE *pbyPkgData = new BYTE[dwPkgSize];
				memmove(pbyPkgData, pbyBuf + iGap, dwPkgSize);
				OnRcvData(pbyPkgData, (WORD)dwPkgSize);

				delete[] pbyPkgData;
				pbyPkgData = NULL;

				nProcSize += iGap + dwPkgSize;
			}
		} while(!bNotGetFullPkg);

		m_dwRemainSizeRcv = nTotalSize - nProcSize;
		memmove(m_pbyCacheBufRcv, m_pbyCacheBufRcv + nProcSize, m_dwRemainSizeRcv);
	}

	CAsyncSocket::OnReceive(nErrorCode);
}

void CTestGameClientSocket::OnClose(int nErrorCode) 
{
	DEBUG_OUT("GameClient:OnClose:%u", nErrorCode);
	
	Close();
	
	CAsyncSocket::OnClose(nErrorCode);
}


#pragma comment(lib, "version.lib")
DWORD CTestGameClientSocket::GetExeVer()
{
	int nRetCode = false;
	
	char szPath[MAX_PATH] = {0};
	::GetModuleFileName(NULL, szPath, MAX_PATH);
	
	DWORD dwInfoSize = ::GetFileVersionInfoSize(szPath, NULL);
	ASSERT(dwInfoSize);
	
	BYTE *pbyInfoBuf = new BYTE[dwInfoSize + 2];
	memset(pbyInfoBuf, 0, dwInfoSize + 2);
	VS_FIXEDFILEINFO *pFileInfo = NULL;
	unsigned int nSize = 0;
	
	::GetFileVersionInfo(szPath, NULL, dwInfoSize, pbyInfoBuf);
	::VerQueryValue(pbyInfoBuf, TEXT("\\"), (void**)&pFileInfo, &nSize);
	
	DWORD dwInnerVer[5] = {0};
	dwInnerVer[0] = pFileInfo->dwFileVersionMS >> 16;
	dwInnerVer[1] = pFileInfo->dwFileVersionMS & 0xffff;
	dwInnerVer[2] = (pFileInfo->dwFileVersionLS >> 16) / 100;
	dwInnerVer[3] = (pFileInfo->dwFileVersionLS >> 16) - dwInnerVer[2] * 100;
	dwInnerVer[4] = pFileInfo->dwFileVersionLS & 0xffff;
	
	delete[] pbyInfoBuf;
	
	return  dwInnerVer[0] * 10000000 + 
		dwInnerVer[1] * 100000 + 
		dwInnerVer[2] * 10000 + 
		dwInnerVer[3] * 100 + 
		dwInnerVer[4];
}


//////////////////////////////////////////////////////////////////////////





CTestGameClientSocketP2P::CTestGameClientSocketP2P():m_pAntiBot(NULL)
{
	m_lstUser.clear();
}

CTestGameClientSocketP2P::~CTestGameClientSocketP2P()
{
	m_lstUser.clear();
}

int CTestGameClientSocketP2P::Init(DWORD dwUin)
{
	int nRetCode = false;

	nRetCode = Create(0, SOCK_DGRAM);
	ASSERT(nRetCode);

	USER_INFO *pstUserInfo = new USER_INFO;
	memset(pstUserInfo, 0, sizeof(USER_INFO));
	pstUserInfo->dwUin = dwUin;

	CString strIp;
	unsigned int unPort = 0;
	nRetCode = GetSockName(strIp, unPort);
	ASSERT(nRetCode);
	strcpy(pstUserInfo->szIp, strIp);
	pstUserInfo->dwPort = unPort;

	m_lstUser.push_back(pstUserInfo);

	return 0;
}

USER_INFO* CTestGameClientSocketP2P::GetSockInfo()
{
	LIST_USER::iterator iter = m_lstUser.begin();
	USER_INFO *pstUserInfo = (USER_INFO*)(*iter);
	return pstUserInfo;
}

//add by gavingu 2007-11-30
USER_INFO* CTestGameClientSocketP2P::GetUserInfoByUin(DWORD dwUserUin)
{
	for(LIST_USER::iterator iter = m_lstUser.begin(); iter != m_lstUser.end(); ++iter)
	{
		if((*iter)->dwUin == dwUserUin)
		{
			return (USER_INFO*)(*iter);
		}
	}
	
	return NULL;
}
//add by gavingu 2007-11-30

int CTestGameClientSocketP2P::SendP2PData(BYTE *pbyData, DWORD dwSize)
{
	int nRetCode = false;

	LIST_USER::iterator iter;
	USER_INFO *pstUserInfo = NULL;

	for (iter = m_lstUser.begin(); iter != m_lstUser.end(); iter++)
	{
		pstUserInfo = (USER_INFO*)(*iter);

		nRetCode = SendTo(pbyData, dwSize, pstUserInfo->dwPort, pstUserInfo->szIp);
		ASSERT(nRetCode == dwSize);
	}
	return 0;
}

int CTestGameClientSocketP2P::OnRcvP2PData(BYTE *pbyData, DWORD dwSize)
{
	
	return 0;
}

void CTestGameClientSocketP2P::OnReceive(int nErrorCode)
{
	int nRetCode = false;

	BYTE byRcvBuf[1024] = {0};
	DWORD dwSize = 1024;
	
	char szPeerIp[32] = {0};
	DWORD dwPeerPort = 0;

	CString strPeerIp;
	unsigned int unPeerPort = 0;
	nRetCode = ReceiveFrom(byRcvBuf, dwSize, strPeerIp, unPeerPort);
	ASSERT(nRetCode > 0 && nRetCode < 1024);
	strcpy(szPeerIp, strPeerIp);
	dwPeerPort = unPeerPort;

	nRetCode = OnRcvP2PData(byRcvBuf, nRetCode);
	ASSERT(nRetCode);
}

void CTestGameClientSocketP2P::OnSend(int nErrorCode)
{
}
void CTestGameClientSocketP2P::OnConnect(int nErrorCode)
{
}
void CTestGameClientSocketP2P::OnClose(int nErrorCode)
{
}