#if !defined(AFX_TESTGAMECLIENTSOCKET_H__420D037C_689C_4F12_915C_70F1BF3CE476__INCLUDED_)
#define AFX_TESTGAMECLIENTSOCKET_H__420D037C_689C_4F12_915C_70F1BF3CE476__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestGameClientSocket.h : header file
//

#include <list>

#pragma pack(push,1)
typedef struct tagGameProtoHead
{
	DWORD dwSize;
	WORD wProtoId;
	DWORD dwCrc;
} GAMEPROTO_HEAD;
#pragma pack(pop)

enum
{
	GAMEPROTO_INIT = 1,
	GAMEPROTO_ANTIBOT = 2,
	GAMEPROTO_GAMESTATUS = 3,
	GAMEPROTO_CLOSE = 11,
	GAMEPROTO_DPROTO = 999,
	GAMEPROTO_TEST_DP = 5,
	GAMEPROTO_REQUESTDATAFORDP = 6,
	SC_AB_VM_PROTO = 7,
	CS_DP_INIT = 8
};

#define MAX_CACHE_BUF_SIZE		(1024 * 1024)
#define MAX_PKG_SIZE			(32 * 1024)


typedef struct tagUserInfo
{
	DWORD dwUin;
	char szIp[32];
	DWORD dwPort;
} USER_INFO;
typedef std::list<USER_INFO*> LIST_USER;

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientSocket command target
#ifdef USE_NEWDP
	class CTestGameClientSocket : public CAsyncSocket, public AntiBot::IClientSink, public AntiBot::IDPClientSink
#else
	class CTestGameClientSocket : public CAsyncSocket, public AntiBot::IClientSink
#endif
{
// Attributes
public:
	void LoginServer(DWORD dwUin, const char *pszSvrIp, WORD wPort, AntiBot::IDProto *pDProto);
	void OnRcvData(BYTE *pbyData, WORD wSize);

	virtual int SendDataToSvr(BYTE *pbyData, DWORD dwSize);

#ifdef USE_NEWDP
	virtual int SendDataToServer(BYTE *pbyData, DWORD dwSize);
#endif	

	void SendData(BYTE *pbyData, WORD wSize);
	void SendData2(BYTE *pbySndData, WORD dwSndSize);

	void EncodeGameProto_Close(BYTE **ppbyGameProtoInitData, DWORD& dwGameProtoInitSize);
	void EncodeGameProto_Init(DWORD dwUin, DWORD dwCliVer, BYTE **ppbyGameProtoInitData, DWORD& dwGameProtoInitSize);
	void EncodeGameProto_AntiBot(BYTE *pbyAntiBotData, DWORD dwAntiBotSize, BYTE **ppbyGameProtoAntiBotData, DWORD& dwGameProtoAntiBotSize);
	void EncodeGameProto_RequestData(BYTE *pbyAntiBotData, DWORD dwAntiBotSize, BYTE **ppbyGameProtoAntiBotData, DWORD& dwGameProtoAntiBotSize);
	void DecodeGameProto(BYTE *pbyGameProtoData, DWORD dwGameProtoSize, BYTE **ppbyData, DWORD& dwSize);
	void EncodeGameProto(BYTE *pbyGameProtoData, DWORD dwGameProtoSize, WORD wProtoId, BYTE **ppbyData, DWORD& dwSize);

	void EncodeGameProto_GameStatus(BYTE byGameStatus, BYTE **ppbyGameStartData, DWORD& dwGameStartSize);

	DWORD GetExeVer();
// Operations
public:
	CTestGameClientSocket();
	virtual ~CTestGameClientSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestGameClientSocket)
	public:
	virtual void OnClose(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnSend(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	virtual void SendClose();
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CTestGameClientSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:	
private:
	BYTE *m_pbyCacheBufRcv;
	DWORD m_dwRemainSizeRcv;

	BYTE *m_pbyCacheBufSnd;
	DWORD m_dwRemainSizeSnd;

	AntiBot::IAntiBot *m_pAntiBot;
	AntiBot::IDProto *m_pDProto;

	DWORD m_dwUin;
	DWORD m_dwPkgCounter;
};




class CTestGameClientSocketP2P : public CAsyncSocket
{
public:
	CTestGameClientSocketP2P();
	virtual ~CTestGameClientSocketP2P();

	int Init(DWORD dwUin);
	
	int SendP2PData(BYTE *pbyData, DWORD dwSize);
	int OnRcvP2PData(BYTE *pbyData, DWORD dwSize);

	void LoginServer(DWORD dwUin, const char *pszSvrIp, WORD wPort);
	void ConnectToServer();
	
	USER_INFO* GetSockInfo();
	USER_INFO* GetUserInfoByUin(DWORD dwUserUin);

	//{{AFX_VIRTUAL(CTestGameClientSocketP2P)
public:
	virtual void OnClose(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnSend(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CTestGameClientSocket)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
private:
	LIST_USER m_lstUser;
	AntiBot::IAntiBot *m_pAntiBot;
	//AntiBot::IDProto *m_pDProto;

	DWORD m_dwUin;
};




/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTGAMECLIENTSOCKET_H__420D037C_689C_4F12_915C_70F1BF3CE476__INCLUDED_)
