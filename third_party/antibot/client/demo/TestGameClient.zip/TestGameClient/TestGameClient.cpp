// TestGameClient.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TestGameClient.h"
#include "TestGameClientDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientApp

BEGIN_MESSAGE_MAP(CTestGameClientApp, CWinApp)
	//{{AFX_MSG_MAP(CTestGameClientApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientApp construction

CTestGameClientApp::CTestGameClientApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTestGameClientApp object

CTestGameClientApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTestGameClientApp initialization

BOOL CTestGameClientApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	if (!AfxSocketInit())
	{
		ASSERT(false);
		return FALSE;
	}

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CTestGameClientDlg *dlg = CTestGameClientDlg::GetInstance();
	m_pMainWnd = dlg;
	int nResponse = dlg->DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
