// Write your custom tests here so you don't have to think about how to compile
// and execute your test code against the exact same library that you are
// currently hacking.

#include <sigc++/sigc++.h>

int main(int, char**)
{
  return 0;
}
